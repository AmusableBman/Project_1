/**
 * 
 */
package gc.cs.comp1011.assignment1;

/**
 * @author Brandon Hewlett
 * @version 20131006
 * This class provides the basic functionality of a traffic light. This class contains
 * its own print statements to let the user know what is happening. 
 */
public class Lights {
	
	//Instance Variables and the Enum for Traffic Lights
	private enum TrafficLights{RED,YELLOW,GREEN};
	TrafficLights tlStatus;
	
	/**
	 * 
	 * Constructor. 
	 * @param initialState. Takes input from the main class. Sets the initial state of the lights
	 */
	public Lights(String initialState){
		switch(initialState){
		case "RED":
			tlStatus = TrafficLights.RED;
			break;
		case "GREEN":
			tlStatus = TrafficLights.GREEN;
			break;
		}
	}
	
	/**
	 * Checks the status of the traffic light and returns a string that states the status
	 * @return String returnString. The string that is returned to the main program
	 */
	public String getLightStatus(){
		String returnString = null;
		
		switch(tlStatus){
		case GREEN:
			returnString = ("The Light is Currently Green");
			break;
		case YELLOW:
			returnString = ("The Light is Currently Yellow");
			break;
		case RED:
			returnString = ("The Light is Currently Red");
			break;
		default:
			returnString= ("The Light does not have a status. Please set one using the setLightStatus method");
			
		}
		return returnString;
	}
	
	/**
	 * Manually sets a new light status on the selected light
	 * @param newLightStatus. Taken from the main class (Can be user input[Not in this version])
	 */
	public void setLightStatus(String newLightStatus){
		
		switch(newLightStatus){
		case "Green":
			tlStatus = TrafficLights.GREEN;
			System.out.println("The light has been manually set to Green");
			break;
		case "Yellow":
			tlStatus = TrafficLights.YELLOW;
			System.out.println("The light has been manually set to Green");
			break;
		case "Red":
			tlStatus = TrafficLights.RED;
			System.out.println("The light has been manually set to Green");
			break;
		default:
			System.out.println("Incorrect. The proper values are 'Red', 'Yellow', and 'Green'. Please input the proper values.");
			break;
			
		}
	}
	
	/**
	 * Does a cycle of the lights. Changes to yellow then red if green, goes straight to green if red. 
	 * @param time. The amount of time (in seconds) that the green light lasts for. This is given in seconds 
	 * and then converted to milliseconds for the purpose of this method.
	 */
	public void CycleLight(int time){
		
		//If it's green...
		if(tlStatus == TrafficLights.GREEN){
			
			System.out.println("Green for " + time + " seconds...");
			
			time = time*1000;
			
			try { 
				Thread.currentThread().sleep(time); 
			} catch ( Exception e ) { 
				
			} 
			
			tlStatus = TrafficLights.YELLOW;
			System.out.println("Light is Yellow");
			
			try { 
				Thread.currentThread().sleep(3000); 
			} catch ( Exception e ) { 
				
			} 
			
			tlStatus = TrafficLights.RED;
			System.out.println("Light is Red");
		
		//if it's red...
		}else if(tlStatus == TrafficLights.RED){
			
			tlStatus = TrafficLights.GREEN;
			System.out.println("Light is Green");
		
		//if it is yellow, or has no status...
		}else{
			
			tlStatus = TrafficLights.RED;
			System.out.println("Light is Red");
		}
		
	}
}
