/**
 * 
 */
package gc.cs.comp1011.assignment1;

/**
 * @author Brandon Hewlett
 * @version 20131006
 * This tester tests all the methods of the Lights class. 
 * All variables are hard-coded, but could be converted to use user input
 */
public class LightsTester {


	public static void main(String[] args) {
		
		//instance variables
		String lightStatusString = null;
		
		//constants
		int GREEN_TIME = 20;
		
		//Simulating a 4-way traffic stop
		Lights northSouthLights = new Lights("RED");
		Lights eastWestLights = new Lights("GREEN");
		
		//Start of testing
		System.out.println("------------------------------------");
		System.out.println("Getter/Setter Methods");
		
		//Testing the getter method
		lightStatusString = northSouthLights.getLightStatus();
		System.out.println(lightStatusString);
		
		//testing the setter method
		northSouthLights.setLightStatus("Green");
		System.out.println("Setting new value for lights, getting value again to make sure");
		
		//making sure the setter worked
		lightStatusString = northSouthLights.getLightStatus();
		System.out.println(lightStatusString);
		
		//setting light back to previous value for cycle testing
		northSouthLights.setLightStatus("Red");
		
		//start of cycle test
		System.out.println("------------------------------------");
		System.out.println("Cycle Lights Method");
		System.out.println("------------------------------------");
		
		//Cycle test
		System.out.println("East-West");
		eastWestLights.CycleLight(GREEN_TIME);
		System.out.println("North-South");
		northSouthLights.CycleLight(GREEN_TIME);
		northSouthLights.CycleLight(GREEN_TIME);
		System.out.println("East-West");
		eastWestLights.CycleLight(GREEN_TIME);

	}

}
