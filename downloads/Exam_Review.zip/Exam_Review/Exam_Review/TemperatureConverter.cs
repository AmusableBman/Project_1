﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Name: Brandon Hewlett
 * Date: October 11, 2013
 * Purpose: Create an application that converts a user-entered temperature from Celcius to Fahrenheit, and vice versa
 * 
 */
namespace Exam_Review
{
    public partial class temperatureForm : Form
    {

        //Declaring Constants
        const int THIRTY_TWO = 32;
        const decimal ONE_POINT_EIGHT = 1.8m;

        public temperatureForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            inputTextBox.Text = "";
            celciusTextBox.Text = "";
            fahrenheitTextBox.Text = "";
            celciusRadioButton.Checked = false;
            fahrenheitRadioButton.Checked = false;
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            decimal inputDecimal, celciusDecimal, fahrenheitDecimal;

            if (inputTextBox.Text != String.Empty)
            {
                try
                {
                    inputDecimal = decimal.Parse(inputTextBox.Text);
                    if (celciusRadioButton.Checked)
                    {
                        celciusDecimal = inputDecimal;
                        fahrenheitDecimal = (inputDecimal * ONE_POINT_EIGHT) + THIRTY_TWO;

                        celciusTextBox.Text = celciusDecimal.ToString("f");
                        fahrenheitTextBox.Text = fahrenheitDecimal.ToString("f");
                    }
                    else if (fahrenheitRadioButton.Checked)
                    {
                        fahrenheitDecimal = inputDecimal;
                        celciusDecimal = (inputDecimal - THIRTY_TWO) / ONE_POINT_EIGHT;

                        celciusTextBox.Text = celciusDecimal.ToString("f");
                        fahrenheitTextBox.Text = fahrenheitDecimal.ToString("f");
                    }
                    else
                    {
                        MessageBox.Show("You MUST select either the Celcius or Fahrenheit Radio Button",
                        "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                catch (FormatException badFormat)
                {
                    MessageBox.Show("Temperature must be a whole number or a decimal.",
                    "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    inputTextBox.Focus();
                }

            }
            else
            {
                MessageBox.Show("The temperature MUST be entered to continue",
                "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                inputTextBox.Focus();
            }

        }
    }
}
